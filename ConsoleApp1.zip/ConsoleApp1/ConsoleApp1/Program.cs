﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SearchFile
{
    class Program
    {
        static void Main(string[] args)
        {
            while (!Ask()) ;
        }

        static bool Ask()
        {
            Console.WriteLine("输入需要遍历的目录：");
            var path = Console.ReadLine();
            if (!Directory.Exists(path))
            {
                Console.WriteLine("文件不存在！");
                return false;
            }
            Console.WriteLine("输入需要查询的文件（包含）：");
            var searchVal = Console.ReadLine();
            var searchPaths = new List<string>();
            ForEachFile(path, searchPaths, searchVal);
            if (searchPaths.Count > 0)
            {
                foreach (var searchPath in searchPaths)
                {
                    Console.WriteLine(searchPath);
                }
            }
            return false;
        }

        static void ForEachFile(string parentPath, List<string> resultPaths, string pattern)
        {
            var dir = new DirectoryInfo(parentPath);
            var childDirectorys = dir.GetDirectories();
            if (childDirectorys.Count() > 0)
            {
                foreach (var childDirectory in childDirectorys)
                {
                    ForEachFile(childDirectory.FullName, resultPaths, pattern);
                }
            }
            var childFiles = dir.GetFiles();
            if (childFiles.Count() > 0)
            {
                foreach (var childFile in childFiles)
                {
                    if (childFile.Name.Contains(pattern))
                    {
                        resultPaths.Add(childFile.FullName);
                    }
                }
            }
        }
    }
}
